package com.cg.service;

import java.util.List;

import com.cg.entities.BillDetails;
import com.cg.entities.Consumer;

public interface CustomerService {

	List<Consumer> getAllConsumers();

	List<BillDetails> getAllBills(int id);

	Consumer getConsumer(int id);

	boolean saveBill(BillDetails billDetails);

	
	
}
