package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="scheduledsessions")
public class SessionEntity {
    @Id
    @Column(name="id")
	private int sessionid;
    @Column(name="name")
    private String sessionname;
    private int duration;
    private String faculty;
    private String mode1;
	public int getSessionid() {
		return sessionid;
	}
	public void setSessionid(int sessionid) {
		this.sessionid = sessionid;
	}
	public String getSessionname() {
		return sessionname;
	}
	public void setSessionname(String sessionname) {
		this.sessionname = sessionname;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getFaculty() {
		return faculty;
	}
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	public String getMode1() {
		return mode1;
	}
	public void setMode1(String mode1) {
		this.mode1 = mode1;
	}
	@Override
	public String toString() {
		return "SessionEntity [sessionid=" + sessionid + ", sessionname=" + sessionname + ", duration=" + duration
				+ ", faculty=" + faculty + ", mode1=" + mode1 + "]";
	}
}
