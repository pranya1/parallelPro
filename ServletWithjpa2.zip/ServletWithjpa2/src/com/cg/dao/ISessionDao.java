package com.cg.dao;

import java.util.List;

import com.cg.entities.SessionEntity;

public interface ISessionDao {
	public	 List<SessionEntity> showSession();
}
