package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import com.cg.entities.SessionEntity;
@Repository
public class SessionDaoImpl implements ISessionDao{
	@PersistenceContext
 EntityManager  entityManager;
	@Override
	public List<SessionEntity> showSession() {
		TypedQuery<SessionEntity> query=entityManager.createQuery("select s from SessionEntity s",SessionEntity.class);
		return query.getResultList();
		
		
	}

}
