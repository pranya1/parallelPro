package com.cg.service;

import java.util.List;

import com.cg.entities.SessionEntity;

public interface ISessionService {
public	 List<SessionEntity> showSession();
}
