package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.ISessionDao;
import com.cg.entities.SessionEntity;
@Service
@Transactional
public class SessionServiceImpl implements ISessionService {
@Autowired
	 ISessionDao iSessionDao;
	
	@Override
	public List<SessionEntity> showSession() {
	
		return iSessionDao.showSession();
	}

}
