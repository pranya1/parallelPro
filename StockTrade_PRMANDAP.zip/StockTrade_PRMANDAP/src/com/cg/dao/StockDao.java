package com.cg.dao;

import java.util.List;

import com.cg.entities.StockMaster;

public interface StockDao {

	List<StockMaster> getAllStock();

	StockMaster getById(int sid);

	double buy(int stock_code, int quantity);

}
