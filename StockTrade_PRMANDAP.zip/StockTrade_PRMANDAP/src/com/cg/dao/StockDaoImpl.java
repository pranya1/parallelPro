package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.StockMaster;

@Repository
public class StockDaoImpl implements StockDao{

	@PersistenceContext
	EntityManager entityManger;

	
	public EntityManager getEntityManager() {
		return entityManger;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManger = entityManager;
	}  
	//method to get all the stock details
	@Override
	public List<StockMaster> getAllStock() {
		TypedQuery<StockMaster> query=entityManger.createQuery("select c from StockMaster c",StockMaster.class);
		
		return query.getResultList();
		
		/*Query query=entityManger.createQuery("from StockMaster");
		List<StockMaster> list=query.getResultList();
		return list;*/
	}
//display the stock details by id
	@Override
	public StockMaster getById(int sid) {
		StockMaster s=entityManger.find(StockMaster.class,sid);
		return s;
	}

	//to buy or sell the stocks
	@Override
	public double buy(int stock_code, int quantity) {
		StockMaster newstock=entityManger.find(StockMaster.class,stock_code);
		double buy=(newstock.getQuote())*quantity;
		return buy;
	}
	
	
	
	
}
