package com.cg.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entities.StockMaster;
import com.cg.service.StockService;

@Controller
public class StockController {
	
	//service layer autowired
	@Autowired
	StockService service;
	
	//displaying the index page 
	@RequestMapping("/index")
	public String index(Model m) {

		List<StockMaster> stocklist = service.getAllProducts();
		m.addAttribute("slist", stocklist);
		return "index";
	}
	//reliance industries stock 
	@RequestMapping("/Reliance Industries")
	public ModelAndView reliance(@RequestParam("stock_code") Integer stock_code, HttpServletRequest request) {

		ModelAndView jsp = new ModelAndView();
		HttpSession session = request.getSession();
		int sid = stock_code;
		StockMaster st1 = service.getById(sid);
		session.setAttribute("user", st1);
		jsp.setViewName("order");
		return jsp;

	}
//tata steel stock
	@RequestMapping("/Tata Steel")
	public ModelAndView tcs(@RequestParam("stock_code") Integer stock_code, HttpServletRequest request) {

		ModelAndView jsp = new ModelAndView();
		HttpSession session = request.getSession();
		int sid = stock_code;
		StockMaster st1 = service.getById(sid);
		session.setAttribute("user", st1);
		jsp.setViewName("order");
		return jsp;

	}
//lnt stock
	@RequestMapping("/LNT")
	public ModelAndView lnt(@RequestParam("stock_code") Integer stock_code, HttpServletRequest request) {

		ModelAndView jsp = new ModelAndView();
		HttpSession session = request.getSession();
		int sid = stock_code;
		StockMaster st1 = service.getById(sid);
		session.setAttribute("user", st1);
		jsp.setViewName("order");
		return jsp;

	}

	//saving the stock details
	@RequestMapping("/save")
	public ModelAndView save(HttpServletRequest request,@RequestParam("opt")String opt) {
		ModelAndView jsp = new ModelAndView();
		double amount;
		int quantity;
		HttpSession session = request.getSession();
		String str=opt;
		
		StockMaster st1=(StockMaster) session.getAttribute("user");
		session.setAttribute("opt",str);
		if(str.charAt(0)=='B') {
			quantity=Integer.parseInt(request.getParameter("quantity"));
			amount=service.buy(st1.getStock_code(),quantity);
		}
		else
		{
			 quantity=Integer.parseInt(request.getParameter("quantity"));
			amount=service.buy(st1.getStock_code(),quantity);
		}
		session.setAttribute("amount", amount);
		session.setAttribute("quantity",quantity);
		jsp.setViewName("summary");
		return jsp;
	}
	
	//summary of purchasing stocks
	@RequestMapping("/summary")
	public ModelAndView summary(HttpServletRequest request) {
		ModelAndView jsp = new ModelAndView();
		jsp.setViewName("summary");
		return jsp;
		
	}
	
}
