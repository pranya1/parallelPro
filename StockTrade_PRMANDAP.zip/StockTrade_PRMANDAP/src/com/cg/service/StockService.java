package com.cg.service;

import java.util.List;

import com.cg.entities.StockMaster;

public interface StockService {

	List<StockMaster> getAllProducts();

	StockMaster getById(int sid);

	double buy(int stock_code, int quantity);

}
