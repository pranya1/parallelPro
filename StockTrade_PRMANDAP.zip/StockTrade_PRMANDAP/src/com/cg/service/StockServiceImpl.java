package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.StockDao;
import com.cg.entities.StockMaster;

@Service
@Transactional
public class StockServiceImpl implements StockService{
	
	//service layer autowired with dao layer
	@Autowired
	StockDao dao;

	@Override
	public List<StockMaster> getAllProducts() {
		// TODO Auto-generated method stub
		return dao.getAllStock();
	}

	@Override
	public StockMaster getById(int sid) {
		// TODO Auto-generated method stub
		return dao.getById(sid);
	}

	@Override
	public double buy(int stock_code, int quantity) {
		// TODO Auto-generated method stub
		return dao.buy(stock_code, quantity);
	}
	
	
	
	
	

}
