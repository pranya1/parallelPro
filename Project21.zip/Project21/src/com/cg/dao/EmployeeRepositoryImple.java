package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Employee;
@Repository
public class EmployeeRepositoryImple implements EmployeeRepository{
@PersistenceContext
	private EntityManager entityManagaer;



	@Override
	public Employee save(Employee employee) {
		entityManagaer.persist(employee);
		entityManagaer.flush();
		return employee;
	}

	@Override
	public List<Employee> loadAll() {
	TypedQuery<Employee> query=	entityManagaer.createQuery("select e from Employee e",Employee.class);
		
		return query.getResultList();
	}

	@Override
	public Employee find(Employee employee) {
		employee=entityManagaer.find(Employee.class, employee.getEmployeeId());
		return employee;
	}

	@Override
	public void update(double sal, long empid) {
		
	Employee	employee=entityManagaer.find(Employee.class,empid);
	employee.setSalary(sal);
		
	}

}
