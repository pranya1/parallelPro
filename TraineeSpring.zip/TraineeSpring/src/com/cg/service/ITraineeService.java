package com.cg.service;

import java.util.List;

import com.cg.entities.Trainee;

public interface ITraineeService 
{
	public Trainee save(Trainee trainer);

	public Trainee find(int i);

	public void update(Trainee trainer);

	public List<Trainee> showall();

	public void delete(Trainee trainer);
	
	

}
