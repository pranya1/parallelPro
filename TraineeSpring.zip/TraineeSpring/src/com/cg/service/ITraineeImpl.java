package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ITraineeDao;
import com.cg.entities.Trainee;

@Service
@Transactional
public class ITraineeImpl implements ITraineeService 
{

	@Autowired
	ITraineeDao traineeDao;
	
	
	
	
	@Override
	public Trainee save(Trainee trainer) {
		
		return traineeDao.save(trainer);
	}





	@Override
	public Trainee find(int id) {
		// TODO Auto-generated method stub
		return traineeDao.find(id);
	}





	@Override
	public void update(Trainee trainer) {
		traineeDao.update(trainer);
	}





	@Override
	public List<Trainee> showall() {
		
		return traineeDao.showAll();
	}





	@Override
	public void delete(Trainee trainer) {
		traineeDao.delete(trainer);
		
	}

	
}
