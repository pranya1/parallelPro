package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Trainee;
import com.cg.service.ITraineeService;

@Controller
public class TraineeController 
{

	@Autowired
	ITraineeService tarinee;
	
	ArrayList<String> locations;
	ArrayList<String> domains;
	
	
	
	
	@RequestMapping(value="/index")
	public String Homepage(Model model)
	{
		locations=new ArrayList<String>();
		locations.add("hyderabad");
		locations.add("chennai");
		locations.add("Mumbai");
		domains=new ArrayList<String>();
		domains.add("java");
		domains.add("C");
		domains.add(".net");
	
		return "index";
		
	}
	
	@RequestMapping(value="/addtrainee")
	public String saveTrainee(Model model)
	{
		model.addAttribute("locations", locations);
		model.addAttribute("domains", domains);
		model.addAttribute("trainer1", new Trainee());
		
		return "addtrainer";
	}
	
	@RequestMapping(value="/save")
	public String saveTrainer(@ModelAttribute("trainer1")Trainee trainer,Model model)
	{
		tarinee.save(trainer);
		return "redirect:/addtrainee.html";
	}
	
	@RequestMapping(value="/modifyTrainee")
	public String updateNewTrainer(Model model)
	{
		return "updateTrainer";
	}
	@RequestMapping(value="/getid")
	public String fetchTrainer(@RequestParam("trainerId")String id,Model model)
	{
		
		Trainee trainer=tarinee.find(Integer.parseInt(id));
		model.addAttribute("fetchTrainer", trainer);
		model.addAttribute("locations", locations);
		model.addAttribute("domains", domains);
		return "updateTrainee";
		
	}
	
	@RequestMapping(value="/update")
	public String updateTrainer(@ModelAttribute("fetchTrainer")Trainee trainer,Model model)
	{
		tarinee.update(trainer);
		return "index";
	}
	
	@RequestMapping(value="/reteriveTrainee")
	public String detailsTrainer(@RequestParam("trainerId")String id,Model model)
	{
		
		Trainee trainer=tarinee.find(Integer.parseInt(id));
		model.addAttribute("fetchTrainerDetails", trainer);
		return "fetchTrainee";	
	}
	@RequestMapping(value="/fetchTrainee")
	public String detailsTrainer1()
	{
		return "fetchTrainee";
	}
	
	@RequestMapping("reteriveAllTrainee")
	public String allDetails(Model model) 
	{
		List<Trainee> trainers=tarinee.showall();
		model.addAttribute("allTrainers", trainers);
		return "fetchAll";
		
	}
	
	@RequestMapping("deleteTrainee")
	public String deleteTrainee()
	{
		return "deleteTrainer";
	}
	
	@RequestMapping(value="/delTrainee")
	public String deleteOperation(@RequestParam("trainerId")String id,Model model)
	{

		Trainee trainer=tarinee.find(Integer.parseInt(id));
		model.addAttribute("deleteTrainerDetails", trainer);
		tarinee.delete(trainer);
		return "deleteTrainer";
		
	}
}
