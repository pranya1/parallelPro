package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.cg.entities.Trainee;

@Repository
public class TraineeDaoImpl implements ITraineeDao 
{


	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Trainee save(Trainee trainer) {
		
		entityManager.persist(trainer);
		
		entityManager.flush();
		return trainer;
		
	}



	@Override
	public Trainee find(int id) {
		// TODO Auto-generated method stub
	Trainee	trainer=entityManager.find(Trainee.class,id);
		return trainer;
	}



	@Override
	public void update(Trainee trainer) {
		// TODO Auto-generated method stub
		Trainee updateTrainer=find(trainer.getId());
		updateTrainer.setDomain(trainer.getDomain());
		updateTrainer.setLocation(trainer.getLocation());
	}



	@Override
	public List<Trainee> showAll() {
		TypedQuery<Trainee> trainers=entityManager.createQuery("select t from Trainee t",Trainee.class);
	//	System.out.println(trainers.getResultList());
		return trainers.getResultList();
	}



	@Override
	public void delete(Trainee trainer) 
	{
		entityManager.remove(trainer);
		
		
	}
	
	

}
