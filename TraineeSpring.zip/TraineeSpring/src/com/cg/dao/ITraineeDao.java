package com.cg.dao;

import java.util.List;

import com.cg.entities.Trainee;

public interface ITraineeDao {

	Trainee save(Trainee trainer);

	Trainee find(int id);

	void update(Trainee trainer);

	List<Trainee> showAll();

	void delete(Trainee trainer);

}
