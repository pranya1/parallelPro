package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Employee;
import com.cg.service.SessionService;

@Controller
public class Mycontroller {
	
	@Autowired
	SessionService service;
	
	@RequestMapping("/index")
	public String display(Model model)
	{
		
List<Employee> employees=service.fetchDetails();
model.addAttribute("employee",employees);
		return "index";
	}
	
	@RequestMapping("/enroll")
	public String showPage(@RequestParam("name") String name, Model model)
	{
		model.addAttribute("name", name);
	    return "enroll";
	}

}
