package com.cg.service;

import java.util.List;

import com.cg.entities.Employee;

public interface SessionService {

	List<Employee> fetchDetails();
	
	
	

}
