package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.SessionDao;
import com.cg.entities.Employee;

@Service
@Transactional
public class SessionServiceImpl implements SessionService {

	@Autowired
	SessionDao dao;
	@Override
	public List<Employee> fetchDetails() {
		// TODO Auto-generated method stub
		return dao.fetchDetails() ;
	}
	
	

	
	
}
