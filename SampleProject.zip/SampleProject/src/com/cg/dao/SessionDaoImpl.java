package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Employee;

@Repository
public class SessionDaoImpl implements SessionDao {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<Employee> fetchDetails() {
		TypedQuery<Employee> query= entityManager.createQuery("select c from Employee c",Employee.class);
		return query.getResultList();
	}
	
}
