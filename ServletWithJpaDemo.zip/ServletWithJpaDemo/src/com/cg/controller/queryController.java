package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


import com.cg.entities.QueryEntity;
import com.cg.service.IQueryService;

@Controller
public class queryController {
	@Autowired
 IQueryService iQueryService;
	
	List<String> solutionGivenBy;
	@RequestMapping("/index")
	public String add(Model model)
	{
		solutionGivenBy=new ArrayList<String>();
		solutionGivenBy.add("uma");
		solutionGivenBy.add("rahul");
		solutionGivenBy.add("kavitha");
		solutionGivenBy.add("hema");
		return "index";
	}
	@RequestMapping("/search")
public String retrive( Model model, @RequestParam("questionid")  String questionId)
{
	QueryEntity query=iQueryService.find(Integer.parseInt(questionId));
	if(query!=null) {
		model.addAttribute("query", query);
		model.addAttribute("solutionGivenBy", solutionGivenBy);
		return "retrive";
	}
	else
	{
		return "index";
	}
}
	@RequestMapping("/submit")
public String saveinfo(@ModelAttribute("query")@Valid QueryEntity queryEntity,BindingResult result,Model model)
	{
		if(result.hasErrors())
		{
			model.addAttribute("query", queryEntity);
			model.addAttribute("solutionGivenBy", solutionGivenBy);
			return "retrive";
		}
		else
		{
			iQueryService.save(queryEntity);
			model.addAttribute("getresult",queryEntity.getQueryId() );
			return "save";
		}
	}

}

