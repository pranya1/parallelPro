package com.cg.Dao;

import com.cg.entities.QueryEntity;

public interface IQueryDao {
	QueryEntity find(int questionid);
	void save(QueryEntity queryEntity);
}
