package com.cg.Dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;


import com.cg.entities.QueryEntity;
@Repository
public class QueryDaoImpl implements IQueryDao{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public QueryEntity find(int questionid) {
		return entityManager.find(QueryEntity.class, questionid);
	}

	@Override
	public void save(QueryEntity queryEntity) {
		QueryEntity queryEntity2=entityManager.find(QueryEntity.class, queryEntity.getQueryId());
		queryEntity2.setSol(queryEntity.getSol());
		queryEntity2.setSolutionGivenBy(queryEntity.getSolutionGivenBy());
		
	}

	
	

}
