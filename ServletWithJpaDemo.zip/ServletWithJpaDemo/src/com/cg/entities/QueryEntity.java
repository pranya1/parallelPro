package com.cg.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="querymaster2")
public class QueryEntity implements Serializable{
	@Id
	@Column(name="queryid")
	private int queryId;
	
	private String tech;
	
	@Column(name="raisedby")
	private String queryRaisedBy;
	
	private String query;
	
	@NotEmpty(message="enter your solution")
	private String sol;
	
	@Column(name="givenby")
	@NotEmpty(message="select your name")
	private String solutionGivenBy;

	public int getQueryId() {
		return queryId;
	}

	public void setQueryId(int queryId) {
		this.queryId = queryId;
	}

	public String getTech() {
		return tech;
	}

	public void setTech(String tech) {
		this.tech = tech;
	}

	public String getQueryRaisedBy() {
		return queryRaisedBy;
	}

	public void setQueryRaisedBy(String queryRaisedBy) {
		this.queryRaisedBy = queryRaisedBy;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getSol() {
		return sol;
	}

	public void setSol(String sol) {
		this.sol = sol;
	}

	public String getSolutionGivenBy() {
		return solutionGivenBy;
	}

	public void setSolutionGivenBy(String solutionGivenBy) {
		this.solutionGivenBy = solutionGivenBy;
	}

	@Override
	public String toString() {
		return "QueryEntity [queryId=" + queryId + ", tech=" + tech + ", queryRaisedBy=" + queryRaisedBy + ", query="
				+ query + ", sol=" + sol + ", solutionGivenBy=" + solutionGivenBy + "]";
	}
	
	
}
