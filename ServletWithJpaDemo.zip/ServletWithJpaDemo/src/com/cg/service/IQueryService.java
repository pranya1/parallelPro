package com.cg.service;

import com.cg.entities.QueryEntity;

public interface IQueryService {
QueryEntity find(int questionid);
void save(QueryEntity queryEntity);
}
