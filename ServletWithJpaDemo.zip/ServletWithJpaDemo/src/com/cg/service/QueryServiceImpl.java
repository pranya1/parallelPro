package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.Dao.IQueryDao;
import com.cg.entities.QueryEntity;
@Service
@Transactional
public class QueryServiceImpl implements IQueryService{
@Autowired
IQueryDao iQueryDao;
	@Override
	public QueryEntity find(int questionid) {
		return iQueryDao.find(questionid);
				
		
		
	}

	@Override
	public void save(QueryEntity queryEntity) {
		iQueryDao.save(queryEntity);
		
	}

}
